/**
 * 
${PARAM_DOC}
 * @author ${USER}
 * @date   ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}:${SECOND}
#if (${TYPE_HINT} != "void") * @return ${TYPE_HINT}
#end
 */