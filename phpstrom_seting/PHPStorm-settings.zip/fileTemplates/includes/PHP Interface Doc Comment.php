/**
 * ${FILE_NAME}  Interface ${NAME}
 * 
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 * @author     ${USER}
 * @date       ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}:${SECOND}
 */